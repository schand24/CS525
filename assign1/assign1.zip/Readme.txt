ADO Assignment3 : Submission

Group Members : 
	Krutharth soni 		(A20340570)
	Tirth Patel             (A20320187)
	Monisha		        (A20320532)
	Saibabu chandramouli    (A20345775)



Assignment Implementations:

*This first Assignment includes implementation of Storage Manager which is capable of all file read write operations.

*Implements empty 
	file creation,
	read operations(readblock,readNextBlock,readPreviiousBlock,readFirstBlock,readLastBlock) 
	write operation(wirteBlock,wirteCurrentblock)
	getCurPos to return the current positon of the cursor in the file
	appendEmpty block to append an array of 4096 bytess to the curren page file.


*Implemented additional error codes returned such as RC_NO_PRIVIOUS_BLOCK,RC_NO_NEXT_BLOCK which are returned depending on the errors occured with in our Storage manager application.

*Test cases provided in the class test_assign1_1.c is executed successfully.

*Implemented additional test cases test_assign1_2.c is executed successfully.


Compiling Instruction: 
We have implemented the following make files (makefile1),(makefile2) 

1.Makefile1 : This includes the test file test_assign1_1.c 

	Command to compile : make -f Makefile1
	Output file generated: assign1
	Command to Run : ./assign1


2.Makefile2:  This includes the test file test_assign1_2.c 

	Command to compile : make -f Makefile2
	Output file generated: assign1_1
	Command to Run : ./assign1_1
